exports.get404 = (req, res, next) => {
  //console.log("coming here");
  res.status(404).render('404',
    {
      pageTitle: 'Page Not Found',
      path: '/pageNotFound',
      isAuthenticated: req.session.isLoggedIn
    });
};

exports.get500 = (req, res, next) => {
  //console.log("coming here");
  res.status(500).render('500', {
    pageTitle: 'Error!',
    path: '/error',
    isAuthenticated: req.session.isLoggedIn
  });
};