/*
const mongodb = require('mongodb');
const MongoClient = mongodb.MongoClient;

let _db;

const mongoConnect = (callback) => {
  MongoClient.connect('mongodb+srv://vrinda:Vri@1234@cluster0-gkso7.mongodb.net/shop?retryWrites=true&w=majority')
    .then(client => {
      console.log("CONNECTED!");
      _db = client.db();
      callback();
    })
    .catch(err => {
      console.log("ERROR: ", err);
      throw err;
    });
};

const getDb = () => {
  if (_db) {
    return _db;
  }
  throw 'No database found!';
};

exports.mongoConnect = mongoConnect;
exports.getDb = getDb;
*/

/* const Sequelize = require('sequelize');

const sequelize = new Sequelize('node_complete', 'root', 'root', {
  dialect: 'mysql',
  host: 'localhost'
});

module.exports = sequelize; */